const Produtos = () => {
    return (
      <div className="bg-red-500 text-white p-4">
        <h1 className="text-2xl font-bold">Produtos</h1>
      </div>
    );
  };
  
  export default Produtos;